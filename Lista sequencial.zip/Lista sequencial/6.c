#include<stdio.h>
int main(){

    int a = 10;
    int b = 5;
  
        printf("%d + %d = %d", a, b, a + b);   
          
    
    return 0;
}