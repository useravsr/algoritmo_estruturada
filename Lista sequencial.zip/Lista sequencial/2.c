#include<stdio.h>
#include<locale.h>
int main(){

    setlocale(LC_ALL,"");

    printf("Caderno de poesias � um belo lugar.\nTantas coisas lindas que eu gostaria de falar.\nEu falo em forma de versos para todos poderem escutar.\nAgora voc� j� sabe por que os poetas passam os dias escrevendo em seus cadernos de poesias.");

    return 0;

}