#include<stdio.h>
int main(){

    int a;
    int b;

        printf("Insira o valor de A e B: ");
        scanf("%d %d", &a, &b);       
        printf("%d + %d = %d", a, b, a + b);   
          
    
    return 0;
}