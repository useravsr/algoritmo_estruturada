#include<stdio.h>
int main(){

    int n1;
    int n2;
    int PROD;

        printf("Insira dois valores inteiros: ");
        scanf("%d %d", &n1, &n2);
        PROD = n1*n2;
        printf("PROD = %d", PROD);

    return 0; 

}